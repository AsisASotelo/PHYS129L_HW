#!/usr/bin/env python3


#p5_hw3.py
#13JUL19	
#


import sys
import numpy as np
print()

while True:
    instr = input("Please enter an integer: ")
    try:
       n = int(instr)
    except ValueError:
       print("Your input was not an integer.  Try again.\n", file=sys.stderr)
    else:
       break
    
 
print("\n\nThe number is %d.\n\n" % n)

print("The factors of",n,"are:")
for i in range(1, n+1):
    if n % i == 0:
        print(i)
