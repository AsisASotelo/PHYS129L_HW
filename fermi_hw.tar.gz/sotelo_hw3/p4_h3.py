#!/usr/bin/env python3

#Problem 4 Homework 3
#Asis A Sotelo
#11Jul2019
#p4_hw3.py

""" Valentines Day """


""" A. Reads in class list file"""

import numpy as np
from io import StringIO
data_set = np.loadtxt("/home/pi/physrpi/coursefiles/classlist.csv", dtype = (str) , delimiter = ',')


print(data_set)
""" Prints out the message wishing each student a Happy Valentines Day"""
#print(type(data_set[1][0]))



#for i in range(len(data_set)):
#    print(("Happy Valentine's Day," +  data_set[i][1] + data_set[i][0] ))
