#!/usr/bin/env python3

#PROBLEM 6 PROGRAM
#
#p6_program.py - Asks user to enter a string prints out string 10 times
#
#05jul2019 Asis A Sotelo

#



instr = input("Please enter a string:")

for i in range(0,9):
	print(instr)


