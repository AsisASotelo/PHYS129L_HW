#!/usr/bin/env python3
#
#p7_hw7.py - Capacitor Potential Relaxation
#
#03Aug19

USAGE = """ Program to solve for and display electronic potential in the neighborhood of a 2D parallel plate capacitor

"""


