#!/bin/bash
# -*- coding: utf-8 -*-

#Asis A Sotelo
#p11_hw4.py
#WGET,GREP,andSED

#18Jul2019